library(gradeR)
library(tidyverse)

# this is the directory with all of the student submissions.
# only works on files with .r or .R file extensions, not .Rmd.
# this is true even when multiple file types in same directory.

# prior to usage ensure that the files are .R or .r files not .Rmd
#  the following line will convert .Rmd to .R

# first set working directory
setwd("~/another-gradeR-vignette")

# import from previously created gradebook (official one for the course)
netids <- read_csv("course-staff-resources/course-semester-gradebook.csv") %>%
  select(NetID)

# now convert .Rmd to .R
for(i in 1:nrow(netids)){
  knitr::purl(input=paste0("student-homework/student-homework00/homework00-",netids[i,],".Rmd"),
            output=paste0("student-homework/student-homework00/homework00-",netids[i,],".R"), 
            documentation = 0)
}            

#  I will use assignment names specifically: lab01-wed1, lab01-wed2, lab01-fri1, lab01-fri2, lab02-wed1 (for week 2 lab)
submission_directory <- "student-homework/student-homework00/"

# Ensure test_that version of solutions is created.
knitr::purl(input="course-staff-resources/homework00/homework00-instructor-solutions.Rmd",
            output="course-staff-resources/homework00/homework00-instructor-solutions.R", 
            documentation = 2)

# do the automatic grading
#  sources are: 
#   1) student submissions directory (where student files reside after pulled from github)
#   2) your_test_file location (where the testthat file for the specific assignment resides)
grades1 <- calcGrades(submission_dir = submission_directory, 
                     your_test_file = "course-staff-resources/homework00/homework00-instructor-solutions.R")

# print out grades object
grades1

# to add specific columns for easier grade distribution
grades2 <- as_tibble(grades1) %>%
  mutate(ID = str_remove_all(str_extract(id, "\\-\\w+\\d+\\."), "\\-|\\.")) %>%
  rowwise() %>%
  mutate(TotalPoints =  sum(c_across(problem01:problem05)))

# print out grades2 object
grades2

# to export the newest version of grades object
write_csv(grades2, "course-staff-resources/homework00/homework00-auto-gradebook.csv")
