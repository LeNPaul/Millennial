#' ---
#' title: "Course Title - Semester Year"
#' output: html_document
#' ---
#' 
#' ## Homework00
#' ### Due: Tuesday August 23, 2022 02:59 pm US Central Time
#' #### Created by Christopher Kinson
#' 
#' Grading Rubric (per question):  
#' 1 point if complete and correct  
#' 0 points otherwise 
#' 
#' 
#' #### Retrieving your work
#' 
#' This and all future homework .Rmd files are written in Markdown. The .Rmd file can be rendered as an .html file for easier viewing. This and all future homework assignments are located in the **homework** directory within the **course-semester-course-content** repo, i.e. **course-semester-course-content/homework** in GitHub. It is always recommended that you **pull** (or refresh) the **course-semester-course-content** repo to ensure that you have the most updated version of all course content including the homework assignments. After pulling (or refreshing) the **course-semester-course-content** repo, the homework file will be in the homework directory. Once you have opened the .Rmd file, you may begin writing your answers beneath each problem. Do not remove any of the original problems from the file, because that makes it more difficult for the course staff to grade your assignment. 
#' 
#' #### Submitting your work
#' 
#' In your individual student repo (named as your netID) in a directory (or folder) called "homework", you are to submit ***two*** files:
#' 
#' a. Your reproducible document file (.Rmd) which should be saved as homework##-netID.Rmd. For example, my homework 01 file would be saved as homework01-kinson2.Rmd.
#' 
#' b. Your rendered reproducible document file (.html) which should be saved as homework##-netID.html. For example, my homework 01 file would be saved as homework01-kinson2.html.
#' 
#' You have an unlimited number of submissions, but only the  latest proper submission (commit and push) will be viewed and graded. **Proper means that the file is correctly named and formatted. Latest means that the file is the most recent submission prior to the deadline. Remember the .Rmd file needs to render properly to .html before submitting.** 
#' 
#' 
#' ***
#' 
#' All students are expected to complete all problems.
#' 
#' **The following problems should be completed by you as an individual. If any problem asks you a particular question, be sure to answer it completely (with code, written sentences, or both).**
#' 
#' ***Do not change anything in this file above the double line. Doing so will prevent your homework from being graded.***
#' 
#' ***
#' ***
#' 
#' ### Use the URLs to access the data. No local files allowed.
#' 
#' 
#' **#1** 
#' 
#' **Problem:** Create an R vector named **prob01** that contains the following 3 elements (in this order): first name, last name, and netID with each element enclosed in quotes. For example, `prob01 <- c("Chris","Kinson", "kinson2")`. This R code should be written in the code chunk of the **Answer** section below.
#' 
#' **Answer:**
#' 
## ---- problem01-------------------------------------------------
library(testthat)
probs01 <- c("FirstName", "LastName", "netID")
test_that("problem01", {
  
  expect_true(is.character(prob01))
  expect_true(length(prob01) == 3)
  expect_true( all(str_count(prob01) > 1) )
  
})
#' 
#' ***
#' 
#' **#2**
#' 
#' **Problem:** Determine whether the statement below is TRUE or FALSE, then create an R vector named **prob02** with the assigned logical value of TRUE or FALSE. For example, `prob02 <- TRUE`. This R code should be written in the code chunk of the **Answer** section below. This code chunk should be executable and able to be evaluated.
#' 
#' - Statement: R's `ifelse` function is vectorized.
#' 
#' **Answer:** 
#' 
## ---- problem02-------------------------------------------------
probs02 <- TRUE
test_that("problem02", {
  
  expect_equal(prob02, TRUE)
  
})
#' 
#' ***
#' 
#' **#3** 
#' 
#' **Problem:** Based on Problem **#2**, create an R vector named **prob03** that contains results of an `ifelse()` function using the first column and first 10 rows of the **iris** dataset only. The iris dataset is accessible internally to R using the code `iris`. The goal of this problem is to provide evidence of your answer to Problem **#2**. **Your prob03 object must be a vector with 10 elements only.**
#' 
#' **Answer:**
#' 
## ---- problem03-------------------------------------------------
probs03 <- ifelse(iris$Sepal.Length[1:10]>5,"long","short")
test_that("problem03", {
  
  expect_true(is.atomic(prob03))
  expect_true(length(prob03) == 10)
  
})
#' 
#' ***
#' 
#' **#4** 
#' 
#' **Problem:** Choose all letters that represent the correct choice(s), then create an R vector named **prob04** with the lower case letter(s) chosen in quotes. If choosing more than one lower case letter, the elements in the vector **prob04** need to be separated by a comma. For example, `prob04 <- c("e","f")`. This R code should be written in the code chunk of the **Answer** section below. This code chunk should be executable and able to be evaluated.
#' 
#' - Question: Which of the following cases are discussed in this course? 
#' 
#' a. pascal case
#' 
#' b. snake case
#' 
#' c. camel case
#' 
#' d. kebab case
#' 
#' e. none of these
#' 
#' **Answer:**
#' 
## ---- problem04-------------------------------------------------
probs04 <- letters[1:4]
test_that("problem04", {
  
  expect_true( all(prob04 %in% letters[1:4]) )
  expect_equal(length(prob04), 4)
  
})
#' 
#' ***
#' 
#' **#5**
#' 
#' **Problem:** Create a character-type vector of length 1 in R named **prob05** with at least two complete sentences that answer the following question(s). This R code should be written in the code chunk of the **Answer** section below. This code chunk should be executable and able to be evaluated.
#' 
#' - Question: In your own words, describe the best way(s) for you to learn new things. What specific things do you require for you to retain information? How frequently do you refer back to notes or textbooks when learning new information?
#' 
#' **Answer:**
#' 
## ---- problem05-------------------------------------------------
probs05 <- "Student answers will vary. We are grading this such that the type of the vector is character, the length of vector is 1, and the string contains at least two sentences."
test_that("problem05", {
  
  expect_true(is.atomic(prob05))
  expect_equal(length(prob05), 1)
  expect_true(stringr::str_count(prob05, "\\.|\\;") > 1)
  
})
#' 
#' ***
#' 
#' **#6** 
#' 
#' **Problem:** Choose a single letter that represents the most correct choice, then create an R vector named **prob06** with the lower case letter chosen in quotes. For example, `prob06 <- "e"`. This R code should be written in the code chunk of the **Answer** section below. This code chunk should be executable and able to be evaluated.
#' 
#' - Question: In which of the following cases is the file name in bold **Homework01Kinson2** written? 
#' 
#' a. pascal case
#' 
#' b. snake case
#' 
#' c. camel case
#' 
#' d. kebab case
#' 
#' e. none of these
#' 
#' **Answer:**
#' 
## ---- problem06-------------------------------------------------
probs06 <- c("a")
test_that("problem06", {
  
  expect_true(is.atomic(prob06))
  expect_equal(length(prob06), 1)
  expect_equal(prob06, "a")
  
})
#' 
#' ***
#' 
#' ## Reminder about submitting this assignment
#' 
#' 1. Remember to create a directory named "homework" in your repo (unless it already exists).  
#' 
#' 2. Inside of your repo's "homework" directory, save (or push) this homework file named as homework00-netID.Rmd, where netID refers to your netID.
#' 
#' 3. Inside of your repo's "homework" directory, save (or push) the rendered homework file named as homework00-netID.html, where netID refers to your netID.
