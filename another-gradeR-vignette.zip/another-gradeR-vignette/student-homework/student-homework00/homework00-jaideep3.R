prob01 <- c("Jaideep", "Mahajan", "jaideep3")

prob02 <- TRUE

prob03 <- ifelse(iris$Sepal.Length>5,"long","short")

prob04 <- c("a","b")

prob05 <- "I don't know. This question is hard for me to answer."

prob06 <- c("a")
