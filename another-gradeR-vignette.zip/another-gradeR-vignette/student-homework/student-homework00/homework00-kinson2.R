prob01 <- c("Chris", "Kinson", "kinson2")

prob02 <- TRUE

prob03 <- ifelse(iris$Sepal.Length[1:10]>5,"long","short")

prob04 <- c("a", "b", "c", "d")

prob05 <- "I learn best when the instructor shares notes and videos that I can look at later after class or before class. I usually look at notes, videos, and textbooks every 2 days to refresh my memory of new materials."

prob06 <- c("a")
