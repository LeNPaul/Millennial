prob01 <- c("Chris", "Kinson", "kinson2")

prob02 <- FALSE

prob03 <- ifelse(iris$Sepal.Length[1:10]>5,"long","short")

prob04 <- c("a","b", "c", "d", "e")

prob05 <- "Too long; didn't read."

prob06 <- c("a")
